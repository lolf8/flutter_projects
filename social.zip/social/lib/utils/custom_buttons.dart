import 'package:flutter/material.dart';

import 'package:social/style/style.dart';

class CustomGradientButton extends StatelessWidget {
  final String _text;
  final VoidCallback _buttonHandler;
  const CustomGradientButton(this._text, this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 45,
      width: MediaQuery.of(context).size.width,
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30.0),
          gradient: const LinearGradient(
              colors: [Color(0xff8247E0), Color(0xffB894F6)])),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        onPressed: _buttonHandler,
        child: Text(
          _text,
          style: buttonTextStyle,
        ),
        shape: const StadiumBorder(),
      ),
    );
  }
}

class CustomButton extends StatelessWidget {
  final String _text;
  final VoidCallback _buttonHandler;
  const CustomButton(this._text, this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(
        top: 10,
        //  bottom: 10,
        // left: 10,
        // right: 10
      ),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(50.0),
          gradient: const LinearGradient(
              colors: [Color(0xffffffff), Color(0xffffffff)])),
      child: MaterialButton(
        // color: Colors.white,
        minWidth: MediaQuery.of(context).size.width,
        onPressed: _buttonHandler,
        child: Text(
          _text,
          style: Theme.of(context).textTheme.subtitle2,
        ),
        shape: const StadiumBorder(),
      ),
    );
  }
}

class CustomOutlineButton extends StatelessWidget {
  final String _text;
  final VoidCallback _buttonHandler;
  const CustomOutlineButton(this._text, this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(
        top: 10,
        //  bottom: 10,
        // left: 10,
        // right: 10
      ),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(50.0),
          border: Border.all(color: const Color(0xff8247E0)),
          gradient: const LinearGradient(
              colors: [Color(0xffffffff), Color(0xffffffff)])),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width - 32,
        splashColor: Colors.white,
        onPressed: _buttonHandler,
        child: Text(
          _text,
          style: Theme.of(context).textTheme.subtitle2,
        ),
      ),
    );
  }
}

class MenuButton extends StatelessWidget {
  final VoidCallback _buttonHandler;
  const MenuButton(this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.all(10.0),
        child: Row(children: [
          IconButton(
              onPressed: _buttonHandler,
              icon: Icon(
                Icons.menu_rounded,
                size: 35,
                color: Colors.white,
              ))
        ]));
  }
}

class BackButtons extends StatelessWidget {
  final VoidCallback _buttonHandler;
  const BackButtons(this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.all(10.0),
        child: Row(children: [
          IconButton(
              onPressed: _buttonHandler,
              icon: Icon(
                Icons.arrow_back_ios_rounded,
                size: 35,
                color: Colors.white,
              ))
        ]));
  }
}

class CustomTransparentBtn extends StatelessWidget {
  final String _text;
  final VoidCallback _buttonHandler;
  const CustomTransparentBtn(this._text, this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 45,
      width: MediaQuery.of(context).size.width,
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30.0),
          gradient: const LinearGradient(
              colors: [Color(0x30000000), Color(0x30000000)])),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        onPressed: _buttonHandler,
        child: Container(
          alignment: Alignment.centerLeft,
          child: Text(
            _text,
            style: buttonTextStyle,
          ),
        ),
        shape: const StadiumBorder(),
      ),
    );
  }
}

class CustomImgPick extends StatelessWidget {
  final String _text;
  final VoidCallback _buttonHandler;
  const CustomImgPick(this._text, this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120,
      width: MediaQuery.of(context).size.width,
      margin: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      decoration: BoxDecoration(
        image: const DecorationImage(
            fit: BoxFit.fill,
            image: NetworkImage(
                "https://media.istockphoto.com/photos/cloud-computing-technology-concept-hand-using-laptop-with-upload-data-picture-id1307122921?b=1&k=20&m=1307122921&s=170667a&w=0&h=mu528w3SFhfdbQs8166qCWPL7sAxCOVeoVJhd8xTmzQ=")),
        borderRadius: BorderRadius.circular(20.0),
        color: const Color(0x30000000),
      ),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        onPressed: _buttonHandler,
        child: Container(
          alignment: Alignment.centerLeft,
          // child: Text(
          //   _text,
          //   style: buttonTextStyle,
          // ),
        ),
        shape: const StadiumBorder(),
      ),
    );
  }
}

class HireDj extends StatelessWidget {
  final String _text;
  final VoidCallback _buttonHandler;
  const HireDj(this._text, this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120,
      width: MediaQuery.of(context).size.width,
      margin: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.grey,
            blurRadius: 20.0, // soften the shadow
            spreadRadius: 0.0, //extend the shadow
            offset: Offset(
              0, // Move to right 10  horizontally
              0, // Move to bottom 10 Vertically
            ),
          )
        ],
        image: const DecorationImage(
            fit: BoxFit.cover,
            image: NetworkImage(
                "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTZ8fG11c2ljJTIwcGxheWxpc3R8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60")),
        borderRadius: BorderRadius.circular(20.0),
        color: const Color(0x30000000),
      ),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        onPressed: _buttonHandler,
        child: Container(
          alignment: Alignment.center,
          child: Text(
            _text,
            style: buttonTextStyle,
          ),
        ),
        shape: const StadiumBorder(),
      ),
    );
  }
}

class SelectPlaylist extends StatelessWidget {
  final String _text;
  final VoidCallback _buttonHandler;
  const SelectPlaylist(this._text, this._buttonHandler);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120,
      width: MediaQuery.of(context).size.width,
      margin: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      decoration: BoxDecoration(
        boxShadow: [
          BoxShadow(
            color: Colors.grey,
            blurRadius: 20.0, // soften the shadow
            spreadRadius: 0.0, //extend the shadow
            offset: Offset(
              0, // Move to right 10  horizontally
              0, // Move to bottom 10 Vertically
            ),
          )
        ],
        image: const DecorationImage(
            fit: BoxFit.cover,
            image: NetworkImage(
                "https://images.unsplash.com/photo-1616356607338-fd87169ecf1a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8cGxheWxpc3R8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60")),
        borderRadius: BorderRadius.circular(20.0),
        color: const Color(0x30000000),
      ),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        onPressed: _buttonHandler,
        child: Container(
          alignment: Alignment.center,
          child: Text(
            _text,
            style: buttonTextStyle,
          ),
        ),
        shape: const StadiumBorder(),
      ),
    );
  }
}
