// import 'package:flutter/material.dart';
// import 'package:video_player/video_player.dart';
// import 'preview.dart';

// class VideoThumbnail extends ViewModelWidget<StackedVideoViewModel> {
//   @override
//   Widget build(BuildContext context, StackedVideoViewModel model) {
//     return Builder(
//       builder: (context) {
//         // If we want to show the full video, we need to scale it to fit the longest side
//         if (model.showFull) {
//           bool wideVideo = model.videoPlayerController.value.size.width >
//               model.videoPlayerController.value.size.height;

//           if (wideVideo) {
//             return Row(
//               children: [
//                 Expanded(
//                     child: AspectRatio(
//                   aspectRatio: model.videoPlayerController.value.aspectRatio,
//                   child: VideoPlayer(model.videoPlayerController),
//                 ))
//               ],
//             );
//           } else {
//             return Column(
//               children: [
//                 Expanded(
//                     child: AspectRatio(
//                   aspectRatio: model.videoPlayerController.value.aspectRatio,
//                   child: VideoPlayer(model.videoPlayerController),
//                 ))
//               ],
//             );
//           }
//         }

//         // Else just show a portion of the video viewport
//         else {
//           return FittedBox(
//             fit: BoxFit.cover,
//             alignment: Alignment(model.x, model.y),
//             child: SizedBox(
//               height: model.videoPlayerController.value.size?.height ?? 0,
//               width: model.videoPlayerController.value.size?.width ?? 0,
//               child: VideoPlayer(model.videoPlayerController),
//             ),
//           );
//         }
//       },
//     );
//   }
// }
