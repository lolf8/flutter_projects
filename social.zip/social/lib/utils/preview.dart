import 'package:social/style/colors.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter/material.dart';

// void main() => runApp(VideoApp());

class VideoApp extends StatefulWidget {
  String url;

  // final Function playPlayer;
  VideoApp({required this.url});

  @override
  _VideoAppState createState() => _VideoAppState();
}

class _VideoAppState extends State<VideoApp> {
  late VideoPlayerController _controller;
  late String videoUrl;
  bool isLoading = true;
  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.network(widget.url)
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {
          _controller.play();
          isLoading = true;
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Video Demo',
      home: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _controller.value.isPlaying
                    ? _controller.pause()
                    : _controller.play();
              });
            },
            child: _controller.value.isInitialized
                ? AspectRatio(
                    aspectRatio: MediaQuery.of(context).size.width <
                            MediaQuery.of(context).size.height
                        ? (MediaQuery.of(context).size.width /
                            MediaQuery.of(context).size.height)
                        : _controller.value.aspectRatio,
                    // _controller.value.aspectRatio,
                    child: Stack(
                      children: [
                        VideoPlayer(_controller),
                        // _ControlsOverlay(controller: _controller),
                        // VideoProgressIndicator(_controller,
                        //     allowScrubbing: true),

                        // isLoading ? CircularProgressIndicator() : SizedBox()
                      ],
                    ),
                  )
                : Stack(
                    children: [
                      AspectRatio(
                          aspectRatio: MediaQuery.of(context).size.width <
                                  MediaQuery.of(context).size.height
                              ? (MediaQuery.of(context).size.width /
                                  MediaQuery.of(context).size.height)
                              : _controller.value.aspectRatio,
                          child: Image(
                              image: NetworkImage(
                                  "https://images.unsplash.com/photo-1502899576159-f224dc2349fa?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8dXJiYW4lMjBpcGhvbmUlMjB3YWxscGFwZXJ8ZW58MHx8MHx8&ixlib=rb-1.2.1&w=1000&q=80"))),
                      CircularProgressIndicator(
                        color: colorPrimary,
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }
}
