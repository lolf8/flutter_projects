import 'dart:io';

import 'package:flutter/material.dart';
import 'package:better_player/better_player.dart';
import 'package:flutter/services.dart';

class DashPage extends StatefulWidget {
  //https://bitmovin-a.akamaihd.net/content/sintel/sintel.mpd
  String url;

  // final Function playPlayer;
  DashPage(
    this.url,
  );

  @override
  _DashPageState createState() => _DashPageState();
}

class _DashPageState extends State<DashPage> {
  late BetterPlayerController _betterPlayerController;
  @override
  void playPlayer() {
    _betterPlayerController.play();
  }

  @override
  void initState() {
    BetterPlayerConfiguration betterPlayerConfiguration =
        const BetterPlayerConfiguration(
      showPlaceholderUntilPlay: true,
      placeholderOnTop: true,
      expandToFill: true,
      aspectRatio: 0.1,
      looping: true,
      autoPlay: true,
      controlsConfiguration: BetterPlayerControlsConfiguration(
        enableFullscreen: false,
        enableSubtitles: false,
        enableQualities: false,
        enableAudioTracks: false,
        enablePlaybackSpeed: false,
        enableRetry: true,
        enableMute: false,
        enableProgressText: false,
        enableProgressBar: false,
        enableProgressBarDrag: false,
        enablePlayPause: false,
        enableSkips: false,
        // enableAudioTracks: false,
        controlBarHeight: 28.0,

        playIcon: Icons.play_circle,
        pauseIcon: Icons.pause_circle,
        // progressBarPlayedColor: Color(0xffB894F6),
        // progressBarHandleColor: Color(0xffB894F6),
        // progressBarBufferedColor: Color(0xFFD6D6D6),
        //customControlsBuilder: (controller) => CustomControlsWidget(controller),
        overflowModalColor: Color(0xFF757575),
        loadingColor: Color(0xffB894F6),
        enablePip: false,
        // overflowMenuIconsColor: Color(0xff8247E0),
      ),
    );

    BetterPlayerDataSource dataSource =
        BetterPlayerDataSource(BetterPlayerDataSourceType.network, widget.url,
            bufferingConfiguration: BetterPlayerBufferingConfiguration(
              minBufferMs: 50000,
              maxBufferMs: 13107200,
              bufferForPlaybackMs: 2500,
              bufferForPlaybackAfterRebufferMs: 5000,
            ),
            cacheConfiguration: BetterPlayerCacheConfiguration(
              useCache: true,
              preCacheSize: 10 * 1024 * 1024,
              maxCacheSize: 10 * 1024 * 1024,
              maxCacheFileSize: 10 * 1024 * 1024,

              ///Android only option to use cached video between app sessions
              key: "testCacheKey",
            ),
            placeholder: Image.network(
              "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
            ),
            useAsmsSubtitles: false,
            useAsmsTracks: false);
    _betterPlayerController = BetterPlayerController(betterPlayerConfiguration);
    _betterPlayerController.setupDataSource(dataSource);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        // color: Colors.transparent,
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: BetterPlayer(
          controller: _betterPlayerController,
        ),
      ),
    );
  }
}
