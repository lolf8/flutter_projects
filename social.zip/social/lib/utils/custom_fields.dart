import 'package:flutter/material.dart';
import 'package:social/style/colors.dart';

import 'package:social/style/style.dart';

class CustomTextFieldSearch extends StatefulWidget {
  final String hintText;

  final double borderRadiusSize;
  const CustomTextFieldSearch(
      @required this.hintText, @required this.borderRadiusSize);
  @override
  _CustomTextFieldSearchState createState() =>
      _CustomTextFieldSearchState(hintText, borderRadiusSize);
}

class _CustomTextFieldSearchState extends State<CustomTextFieldSearch> {
  final TextEditingController _value = TextEditingController();
  final String hintText;
  final double borderRadiusSize;
  _CustomTextFieldSearchState(this.hintText, this.borderRadiusSize);
  @override
  void dispose() {
    _value.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print(borderRadiusSize);
    return SizedBox(
      height: 40,
      child: TextFormField(
        controller: _value,
        validator: (value) {
          if (value == null || value.length < 3 || value.isEmpty) {
            return "Enter at least 3 character";
          }
        },
        decoration: InputDecoration(
          contentPadding: const EdgeInsets.only(left: 25),
          focusedErrorBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(borderRadiusSize),
          ),
          errorBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(borderRadiusSize),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(borderRadiusSize),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.circular(borderRadiusSize),
          ),
          hintText: hintText,
          // counterStyle: BoxDecoration(border: ),
          hintStyle: TextStyle(color: Colors.grey),
          fillColor: Color(0x30000000),
          filled: true,
          suffixIcon: Icon(
            Icons.search_rounded,
            color: Colors.white,
          ),
        ),
        cursorColor: colorPrimaryDark,
        autocorrect: false,
        style: const TextStyle(
            color: Colors.white,
            // fontSize: 14.0,
            fontFamily: 'montserrat',
            fontWeight: FontWeight.w400),
      ),
    );
  }
}
