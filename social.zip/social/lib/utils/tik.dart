import 'package:expandable_text/expandable_text.dart';
import 'package:flutter/material.dart';
import 'package:like_button/like_button.dart';
import 'package:marquee/marquee.dart';
import 'package:social/model/videos.dart';
import 'package:social/pages/audio_related.dart';
import 'package:social/style/colors.dart';
import 'package:social/utils/preview.dart';
import 'package:tiktoklikescroller/tiktoklikescroller.dart';
import 'player.dart';

class HomeWidget extends StatefulWidget {
  HomeWidget();

  @override
  State<HomeWidget> createState() => _HomeWidgetState();
}

class _HomeWidgetState extends State<HomeWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView.builder(
        scrollDirection: Axis.vertical,
        // onPageChanged: (value) {
        //   DashPage(videoArr[value].url);
        // },
        itemCount: videoArr.length,
        itemBuilder: (context, index) {
          return Stack(
            children: [
              Positioned(
                top: 0,
                left: 0,
                child: SizedBox(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  child:
                      // DashPage(videoArr[index].url),
                      VideoApp(url: videoArr[index].url),
                ),
              ),
              Positioned(
                top: 40,
                left: 3,
                child: IconButton(
                  iconSize: 30,
                  onPressed: () => Navigator.pop(context),
                  icon: Icon(Icons.arrow_back_ios_new_rounded),
                  color: Colors.white,
                ),
              ),
              Positioned(
                top: 40,
                right: 10,
                child: IconButton(
                  iconSize: 30,
                  onPressed: () {},
                  icon: Icon(Icons.camera_alt_rounded),
                  color: Colors.white,
                ),
              ),
              Positioned(
                bottom: 100,
                right: 5,
                child: Container(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: LikeButton(
                          size: 30,
                          countPostion: CountPostion.bottom,
                          circleColor: CircleColor(
                            start: colorPrimary,
                            // Color(0xff00ddff),
                            end: colorPrimaryDark,
                          ),
                          // Color(0xff0099cc)),
                          bubblesColor: BubblesColor(
                              dotPrimaryColor: colorPrimary,
                              dotSecondaryColor: colorPrimaryDark
                              // Color(0xff0099cc),
                              ),
                          likeBuilder: (bool isLiked) {
                            return isLiked
                                ? Image.asset("images/clapping_solid.png")
                                : Image.asset("images/clapping_stroke.png");
                          },
                          likeCount: 665,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: IconButton(
                          iconSize: 30,
                          onPressed: () {},
                          icon: Image.asset("images/commentary.png"),
                          color: Colors.white,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: IconButton(
                          iconSize: 30,
                          onPressed: () {},
                          icon: Icon(Icons.remove_red_eye_outlined),
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 30,
                left: 10,
                child: LimitedBox(
                  maxWidth: MediaQuery.of(context).size.width - 90,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      ExpandableText(
                        'Short text',
                        style: TextStyle(color: colorWhite),
                        expandText: 'show more',
                        collapseText: 'show less',
                      ),
                      SizedBox(height: 10.0),
                      ExpandableText(
                        'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.',
                        expandText: 'show more',
                        style: TextStyle(color: colorWhite),
                        expandOnTextTap: true,
                        collapseOnTextTap: true,
                        animation: true,
                        animationCurve: Curves.decelerate,
                        collapseText: 'show less',
                        maxLines: 1,
                        linkColor: Colors.blueGrey,
                      ),
                      LimitedBox(
                        maxHeight: 40,
                        maxWidth: MediaQuery.of(context).size.width - 90,
                        child: Container(
                          child: GestureDetector(
                              child: Marquee(
                                text:
                                    "Currently Playing Audio---Currently Playing Audio---Currently Playing Audio",
                                style: TextStyle(color: colorWhite),
                                fadingEdgeEndFraction: 0.2,
                              ),
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => AudioRelated()));
                              }),
                        ),
                      )
                    ],
                  ),
                ), // T
              ),
              Positioned(
                bottom: 35,
                right: 20,
                child: GestureDetector(
                    child: Container(
                      height: 35,
                      width: 35,
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.white, width: 3),
                          borderRadius: BorderRadius.circular(7),
                          color: Colors.transparent),
                    ),
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => AudioRelated()));
                    }),
              )
            ],
          );
        },
        // contentSize: videoArr.length,
        // swipePositionThreshold: 0.2,
        // // ^ the fraction of the screen needed to scroll
        // swipeVelocityThreshold: 2000,
        // // ^ the velocity threshold for smaller scrolls
        // animationDuration: const Duration(milliseconds: 300),
        // // ^ how long the animation will take
        // onScrollEvent: _handleCallbackEvent,
        // // ^ registering our own function to listen to page changes
        // builder: (BuildContext context, int index) {
        //   return Container(
        //     // color: Vido[index],
        //     child: Stack(
        //       children: [
        //         Positioned(
        //           top: 0,
        //           left: 0,
        //           child: SizedBox(
        //             height: MediaQuery.of(context).size.height,
        //             width: MediaQuery.of(context).size.width,
        //             child: DashPage(videoArr[index].url),
        //           ),
        //         ),
        //         Positioned(
        //           top: 40,
        //           left: 3,
        //           child: IconButton(
        //             iconSize: 35,
        //             onPressed: () => Navigator.pop(context),
        //             icon: Icon(Icons.arrow_back_ios_new),
        //             color: Colors.white,
        //           ),
        //         ),
        //         Positioned(
        //           top: 40,
        //           right: 10,
        //           child: IconButton(
        //             iconSize: 35,
        //             onPressed: () {},
        //             icon: Icon(Icons.camera_alt_outlined),
        //             color: Colors.white,
        //           ),
        //         ),
        //         Positioned(
        //           bottom: 100,
        //           right: 5,
        //           child: Container(
        //             child: Column(
        //               children: [
        //                 Padding(
        //                   padding: const EdgeInsets.all(8.0),
        //                   child: LikeButton(
        //                     size: 40,
        //                   ),
        //                 ),
        //                 Padding(
        //                   padding: const EdgeInsets.all(8.0),
        //                   child: IconButton(
        //                     iconSize: 30,
        //                     onPressed: () {},
        //                     icon: Icon(Icons.comment),
        //                     color: Colors.white,
        //                   ),
        //                 ),
        //                 Padding(
        //                   padding: const EdgeInsets.all(8.0),
        //                   child: IconButton(
        //                     iconSize: 30,
        //                     onPressed: () {},
        //                     icon: Icon(Icons.send),
        //                     color: Colors.white,
        //                   ),
        //                 ),
        //               ],
        //             ),
        //           ),
        //         ),
        //         Positioned(
        //           bottom: 30,
        //           left: 10,
        //           child: LimitedBox(
        //             maxWidth: MediaQuery.of(context).size.width - 90,
        //             child: Column(
        //               crossAxisAlignment: CrossAxisAlignment.start,
        //               children: <Widget>[
        //                 ExpandableText(
        //                   'Short text',
        //                   style: TextStyle(color: colorWhite),
        //                   expandText: 'show more',
        //                   collapseText: 'show less',
        //                 ),
        //                 SizedBox(height: 10.0),
        //                 ExpandableText(
        //                   'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.',
        //                   expandText: 'show more',
        //                   style: TextStyle(color: colorWhite),
        //                   expandOnTextTap: true,
        //                   collapseOnTextTap: true,
        //                   animation: true,
        //                   animationCurve: Curves.decelerate,
        //                   collapseText: 'show less',
        //                   maxLines: 1,
        //                   linkColor: Colors.blueGrey,
        //                 ),
        //                 LimitedBox(
        //                   maxHeight: 40,
        //                   maxWidth: MediaQuery.of(context).size.width - 90,
        //                   child: Container(
        //                     child: GestureDetector(
        //                         child: Marquee(
        //                           text:
        //                               "Currently Playing Audio---Currently Playing Audio---Currently Playing Audio",
        //                           style: TextStyle(color: colorWhite),
        //                           fadingEdgeEndFraction: 0.2,
        //                         ),
        //                         onTap: () {
        //                           Navigator.push(
        //                               context,
        //                               MaterialPageRoute(
        //                                   builder: (context) =>
        //                                       AudioRelated()));
        //                         }),
        //                   ),
        //                 )
        //               ],
        //             ),
        //           ), // T
        //         ),
        //         Positioned(
        //           bottom: 35,
        //           right: 20,
        //           child: GestureDetector(
        //               child: Container(
        //                 height: 35,
        //                 width: 35,
        //                 decoration: BoxDecoration(
        //                     border: Border.all(color: Colors.white, width: 3),
        //                     borderRadius: BorderRadius.circular(7),
        //                     color: Colors.transparent),
        //               ),
        //               onTap: () {
        //                 Navigator.push(
        //                     context,
        //                     MaterialPageRoute(
        //                         builder: (context) => AudioRelated()));
        //               }),
        //         )
        //       ],
        //     ),
        //   );
        // },
      ),
    );
  }

  void _handleCallbackEvent(ScrollEventType type, {int? currentIndex}) {
    print(
        "Scroll callback received with data: {type: $type, and index: ${currentIndex ?? 'not given'}}");
  }
}
