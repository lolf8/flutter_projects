import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

Color colorPrimary = Color(0xFFB894F6);
Color colorPrimaryDark = Color(0xFF8247E0);
Color colorBackground = Color(0xFF272E3C);
Color backgroundGrey = Color(0xFF373e4a);
Color backgroundGreyDark = Color(0xFF181c25);
Color colorWhite = Colors.white;
