var appName = "RENAO";

var next = "next";

String Kprofile = 'myImage';