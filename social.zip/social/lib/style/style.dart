import 'package:flutter/material.dart';
import 'package:social/style/colors.dart';

ThemeData lightTheme = ThemeData(
  scaffoldBackgroundColor: colorWhite,
  appBarTheme: AppBarTheme(
    color: colorPrimary,
    iconTheme: IconThemeData(color: colorBackground),
  ),
  colorScheme: ColorScheme.light(
      primary: colorPrimary,
      primaryVariant: colorPrimaryDark,
      secondary: colorPrimaryDark,
      onPrimary: colorBackground,
      background: backgroundGrey,
      onSurface: colorWhite,
      surface: colorBackground,
      onSecondary: backgroundGreyDark,
      secondaryVariant: backgroundGreyDark),
  iconTheme: IconThemeData(
    color: colorBackground,
  ),
  textTheme: _lightTextTheme,
  tabBarTheme: _lightTabBarTheme,
);

ThemeData darkTheme = ThemeData(
  scaffoldBackgroundColor: backgroundGrey,
  appBarTheme: AppBarTheme(
    color: backgroundGrey,
    iconTheme: IconThemeData(color: backgroundGreyDark),
  ),
  colorScheme: ColorScheme.dark(
      primary: colorPrimary,
      primaryVariant: colorPrimaryDark,
      secondary: colorPrimaryDark,
      onPrimary: colorBackground,
      background: backgroundGrey,
      onSurface: backgroundGrey,
      surface: colorWhite,
      onSecondary: backgroundGreyDark,
      secondaryVariant: backgroundGreyDark),
  iconTheme: IconThemeData(
    color: colorWhite,
  ),
  textTheme: _darkTextTheme,
  tabBarTheme: _darkTabBarTheme,
);

final TextTheme _lightTextTheme = TextTheme(
  bodyText1: TextStyle(
    fontWeight: FontWeight.w600,
    fontSize: 14,
    color: colorWhite,
    fontFamily: 'montserrat',
  ),
  bodyText2: TextStyle(
    fontSize: 18.3,
    letterSpacing: 1.0,
    color: Colors.grey,
  ),
  headline1: TextStyle(
    color: colorBackground,
    fontSize: 14.0,
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
    letterSpacing: 0.5,
  ),
  headline2: TextStyle(
    color: colorBackground,
    fontSize: 16.0,
    fontWeight: FontWeight.w400,
    fontFamily: 'Roboto',
    letterSpacing: 0.5,
  ),
  headline3: TextStyle(
    color: colorBackground,
    fontSize: 22.0,
    fontWeight: FontWeight.w400,
    fontFamily: 'Roboto',
    letterSpacing: 0.5,
  ),
  headline4: TextStyle(
    color: colorBackground,
    fontWeight: FontWeight.w400,
    fontFamily: 'Roboto',
    fontSize: 16.7,
  ),
  headline5: TextStyle(
    fontWeight: FontWeight.w500,
    color: colorBackground,
    fontSize: 18.0,
    fontFamily: 'Roboto',
    letterSpacing: 0.5,
  ),
  headline6: TextStyle(
      color: colorBackground,
      fontSize: 28,
      fontFamily: 'Roboto',
      fontWeight: FontWeight.w700,
      letterSpacing: 1.0
  ),
);

final TextTheme _darkTextTheme = TextTheme(
  bodyText1: TextStyle(
    fontWeight: FontWeight.w600,
    fontSize: 14,
    color: colorWhite,
    fontFamily: 'montserrat',
  ),
  bodyText2: TextStyle(
    fontSize: 18.3,
    letterSpacing: 1.0,
    color: Colors.grey,
  ),
  headline1: TextStyle(
    color: colorWhite,
    fontSize: 14.0,
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
    letterSpacing: 0.5,
  ),
  headline2: TextStyle(
    color: colorWhite,
    fontSize: 16.0,
    fontWeight: FontWeight.w400,
    fontFamily: 'Roboto',
    letterSpacing: 0.5,
  ),
  headline3: TextStyle(
    color: colorWhite,
    fontSize: 22.0,
    fontWeight: FontWeight.w400,
    fontFamily: 'Roboto',
    letterSpacing: 0.5,
  ),
  headline4: TextStyle(
    color: colorWhite,
    fontWeight: FontWeight.w400,
    fontFamily: 'Roboto',
    fontSize: 16.7,
  ),
  headline5: TextStyle(
    fontWeight: FontWeight.w500,
    color: colorWhite,
    fontSize: 18.0,
    fontFamily: 'Roboto',
    letterSpacing: 0.5,
  ),
  headline6: TextStyle(
      color: colorWhite,
      fontSize: 28,
      fontFamily: 'Roboto',
      fontWeight: FontWeight.w700,
      letterSpacing: 1.0
  ),
);

final TabBarTheme _lightTabBarTheme = TabBarTheme(
  //unselectedLabelColor: colorBackground,
  //labelColor: colorPrimaryDark,
  unselectedLabelStyle: TextStyle(
      fontSize: 16.0,
      color: colorBackground,
      fontFamily: 'Roboto',
      fontWeight: FontWeight.w500
  ),
  labelStyle: TextStyle(
      fontSize: 16.0,
      color: colorPrimaryDark,
      fontFamily: 'Roboto',
      fontWeight: FontWeight.w500
  ),
);

final TabBarTheme _darkTabBarTheme = TabBarTheme(
  //unselectedLabelColor: colorWhite,
  unselectedLabelStyle: TextStyle(
      fontSize: 16.0,
      color: colorWhite,
      fontFamily: 'Roboto',
      fontWeight: FontWeight.w500
  ),
  //labelColor: colorPrimaryDark,
  labelStyle: TextStyle(
      fontSize: 16.0,
      color: colorPrimaryDark,
      fontFamily: 'Roboto',
      fontWeight: FontWeight.w500
  ),
);

final TextStyle buttonTextStyle = TextStyle(
    fontSize: 14.0,
    color: colorWhite,
    fontFamily: 'montserrat',
    fontWeight: FontWeight.w400
);