import 'package:flutter/material.dart';
import 'package:like_button/like_button.dart';
import 'package:social/utils/custom_fields.dart';
import 'package:social/utils/tik.dart';

// import 'models.dart/model.dart';
import 'model/model.dart';
import 'model/videos.dart';
import 'style/colors.dart';

class MusicList extends StatelessWidget {
  const MusicList({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("data"),
      ),
      body: Container(
        // color: Colors.blueGrey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 23, top: 23, right: 23),
              child: Container(
                child: CustomTextFieldSearch("Search music", 20),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                top: 20,
                left: 12,
              ),
              child: Text(
                "Trending",
                style: TextStyle(
                    color: colorBackground,
                    fontSize: 17,
                    fontFamily: 'montserrat',
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.0),
              ),
            ),
            SizedBox(
              height: 500,
              width: MediaQuery.of(context).size.width,
              child: ListView.builder(
                scrollDirection: Axis.vertical,
                itemCount: cardsListArr.length,
                itemBuilder: (context, index) {
                  return Container(
                    margin: const EdgeInsets.only(top: 10, left: 12, right: 8),
                    height: MediaQuery.of(context).size.height * 0.059,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: Colors.transparent),
                    child: GestureDetector(
                      onTap: () {
                        // showResults(context);
                      },
                      child: Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: Container(
                              height: MediaQuery.of(context).size.height,
                              // width: MediaQuery.of(context).size.width * 0.25,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                image: DecorationImage(
                                  image: NetworkImage(
                                      cardsListArr[index].imgPoster),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 5,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: Container(
                                  height: MediaQuery.of(context).size.height,
                                  width: MediaQuery.of(context).size.width,
                                  padding:
                                      const EdgeInsets.only(left: 5, right: 5),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        cardsListArr[index].title,
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline6,
                                      ),
                                      Text(
                                        cardsListArr[index].subtitle,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText2,
                                      ),
                                    ],
                                  )),
                            ),
                          ),
                          IconButton(
                              onPressed: () {},
                              icon: Icon(Icons.play_circle_rounded),
                              iconSize: 27)
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            ElevatedButton(
                onPressed: () {
                  showModalBottomSheet<void>(
                      context: context,
                      builder: (BuildContext context) {
                        return Container(
                          height: 200,
                          color: Colors.amber,
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                const Text('Modal BottomSheet'),
                                ElevatedButton(
                                  child: const Text('Close BottomSheet'),
                                  onPressed: () => Navigator.pop(context),
                                )
                              ],
                            ),
                          ),
                        );
                      });
                },
                child: Text("data")),
            ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomeWidget(),
                      ));
                },
                child: Text("Short Videos")),
          ],
        ),
      ),
    );
  }
}
