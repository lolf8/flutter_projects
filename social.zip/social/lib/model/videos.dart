class VideoUrl {
  final String url;

  VideoUrl({required this.url});
}

var videoArr = [
  VideoUrl(
      url:
          "https://player.vimeo.com/external/551674951.hd.mp4?s=33b3cd6bd3002de191f7e8105e09d6eee56b17f6&profile_id=172&oauth2_token_id=57447761"),

  VideoUrl(
      url:
          "https://nyc3.digitaloceanspaces.com/gpslabindia/cheekolite/upload/video/1594525278_405413081.mp4"),
  VideoUrl(
      url:
          "https://nyc3.digitaloceanspaces.com/gpslabindia/cheekolite/upload/video/1594041106_1103596858.mp4"),

  VideoUrl(
      url:
          "https://nyc3.digitaloceanspaces.com/gpslabindia/cheekolite/upload/video/1594521350_1225639532.mp4"),
  VideoUrl(
      url:
          "https://nyc3.digitaloceanspaces.com/gpslabindia/cheekolite/upload/video/1594114679_479266563.mp4"),
  VideoUrl(
      url:
          "https://nyc3.digitaloceanspaces.com/gpslabindia/cheekolite/upload/video/1594525278_405413081.mp4"),

  // VideoUrl(url: "https://bitmovin-a.akamaihd.net/content/sintel/sintel.mpd"),
  VideoUrl(
      url:
          "https://player.vimeo.com/external/364865160.hd.mp4?s=1d33d71a8170c06b6a197ed9972ffe8e9d8a832f&profile_id=175&oauth2_token_id=57447761"),
];
