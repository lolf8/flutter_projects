class CardsList {
  final String title;
  final String subtitle;
  final String imgPoster;

  CardsList(
      {required this.title, required this.subtitle, required this.imgPoster});
}

var cardsListArr = [
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "In The End",
    subtitle: "Nucleya",
    imgPoster:
        "https://images.pexels.com/photos/2880793/pexels-photo-2880793.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "STAY",
    subtitle: "Nikhil Chinappa",
    imgPoster:
        "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Where Are You",
    subtitle: "DJ NYK",
    imgPoster:
        "https://images.pexels.com/photos/7715460/pexels-photo-7715460.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Kuch To Bata Zindagi",
    subtitle: "DJ Chetas",
    imgPoster:
        "https://images.pexels.com/photos/8119500/pexels-photo-8119500.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
  CardsList(
    title: "Lovely",
    subtitle: "DJ Zaeden",
    imgPoster:
        "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
  ),
];
