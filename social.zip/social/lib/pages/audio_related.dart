import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:social/model/model.dart';
import 'package:social/style/colors.dart';
import 'package:social/utils/position_seek_widget.dart';
import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:lottie/lottie.dart';

class AudioRelated extends StatefulWidget {
  AudioRelated({Key? key}) : super(key: key);

  @override
  State<AudioRelated> createState() => _AudioRelatedState();
}

class _AudioRelatedState extends State<AudioRelated>
    with TickerProviderStateMixin {
  final mp3Url =
      'https://files.freemusicarchive.org/storage-freemusicarchive-org/music/Music_for_Video/springtide/Sounds_strange_weird_but_unmistakably_romantic_Vol1/springtide_-_03_-_We_Are_Heading_to_the_East.mp3';

  late final AnimationController _controller;

  final bool isExtended = false;
  late bool isVisible = true;

  final assetsAudioPlayer = AssetsAudioPlayer();

  void openPlayer(String url) async {
    try {
      await assetsAudioPlayer.open(
        Audio.network(
          url,
        ),
        autoStart: true,
        audioFocusStrategy: AudioFocusStrategy.request(
            resumeAfterInterruption: true, resumeOthersPlayersAfterDone: true),
      );
    } catch (t) {
      //mp3 unreachable
      print("error : ${t.toString()}");
    }
  }

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
    );
    openPlayer(mp3Url);
  }

  @override
  void dispose() {
    assetsAudioPlayer.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
    ));
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloatingActionButton.extended(
          backgroundColor: colorPrimaryDark,
          onPressed: () {},
          label: AnimatedSwitcher(
            duration: Duration(seconds: 1),
            transitionBuilder: (Widget child, Animation<double> animation) =>
                FadeTransition(
              opacity: animation,
              child: SizeTransition(
                child: child,
                sizeFactor: animation,
                axis: Axis.horizontal,
              ),
            ),
            child: isExtended
                ? Icon(Icons.camera_alt_rounded)
                : Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 4.0),
                        child: Icon(Icons.camera_alt_rounded),
                      ),
                      Text(
                        "Use Audio",
                        style: TextStyle(fontSize: 12),
                      )
                    ],
                  ),
          )),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              height: AppBar().preferredSize.height,
              child: Stack(
                children: [
                  Positioned(
                    left: 0,
                    child: Row(
                      children: [
                        IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: Icon(
                              Icons.arrow_back_ios_new_rounded,
                              size: 28,
                              // color: Theme.of(context).iconTheme.color,
                            )),
                        Padding(
                          padding: const EdgeInsets.only(left: 15.0),
                          child: Text(
                            'Audio',
                            textAlign: TextAlign.center,
                            style: Theme.of(context).textTheme.headline6,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                          onPressed: () {},
                          icon: Icon(
                            Icons.send_rounded,
                            size: 28,
                            color: Theme.of(context).iconTheme.color,
                          ),
                        ),
                        IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.more_vert,
                              size: 28,
                              color: Theme.of(context).iconTheme.color,
                            )),
                      ],
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Container(
                    height: MediaQuery.of(context).size.shortestSide * 0.21,
                    width: MediaQuery.of(context).size.shortestSide * 0.21,
                    // width: MediaQuery.of(context).size.width * 0.25,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(11),
                      image: DecorationImage(
                        image: NetworkImage(
                            "https://images.pexels.com/photos/3682820/pexels-photo-3682820.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height: MediaQuery.of(context).size.shortestSide * 0.19,
                      width: MediaQuery.of(context).size.shortestSide * 0.68,
                      // color: Colors.amber,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Song_Name",
                            style: Theme.of(context).textTheme.headline6,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 5.0),
                            child: Text(
                              "_author",
                              style: Theme.of(context).textTheme.bodyText1,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 5.0),
                            child: Text(
                              "int_used_count",
                              style: TextStyle(color: Colors.grey),
                            ),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 1.0),
                  child: PlayerBuilder.isPlaying(
                    player: assetsAudioPlayer,
                    builder: (context, isPlaying) {
                      return IconButton(
                        onPressed: () {
                          if (isPlaying) {
                            assetsAudioPlayer.pause();
                            setState(() {
                              isVisible = false;
                            });
                          } else {
                            assetsAudioPlayer.play();
                            setState(() {
                              isVisible = true;
                            });
                            // openPlayer(mp3Url);
                          }
                        },
                        color: colorPrimaryDark,
                        icon: isPlaying
                            ? Icon(Icons.pause_rounded)
                            : Icon(Icons.play_arrow_rounded),
                      );
                    },
                  ),
                ),
                Stack(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.81,
                      child: assetsAudioPlayer.builderRealtimePlayingInfos(
                          builder: (context, realtimePlayingInfos) {
                        _controller.duration = realtimePlayingInfos.duration;
                        return PositionSeekWidget(
                          currentPosition: realtimePlayingInfos.currentPosition,
                          duration: realtimePlayingInfos.duration,
                          seekTo: (to) {
                            assetsAudioPlayer.seek(to);
                          },
                        );
                      }),
                    ),
                    Positioned(
                      top: 3,
                      left: 25,
                      child: Visibility(
                        visible: isVisible,
                        child: SizedBox(
                          child: Lottie.asset(
                            'raw/visualizer.json',
                            width: MediaQuery.of(context).size.width * 0.57,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            // SizedBox(
            //   height: 2,
            //   width: MediaQuery.of(context).size.width,
            // ),
            Container(
              height: MediaQuery.of(context).size.shortestSide * 0.09,
              margin: const EdgeInsets.only(
                bottom: 12,
              ),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.0),
                  border: Border.all(color: const Color(0xff8247E0)),
                  gradient: const LinearGradient(
                      colors: [Color(0xffffffff), Color(0xffffffff)])),
              child: MaterialButton(
                minWidth: MediaQuery.of(context).size.width - 32,
                splashColor: Colors.white,
                onPressed: () {},
                child: Text(
                  "SAVE",
                  style: TextStyle(color: colorPrimary, fontSize: 13),
                ),
              ),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 0.641,
              child: GridView.builder(
                  shrinkWrap: true,
                  itemCount: cardsListArr.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: MediaQuery.of(context).size.width /
                        (MediaQuery.of(context).size.height / 1.4),
                  ),
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(1.0),
                      child: Container(
                        decoration: BoxDecoration(
                          // shape: BoxShape.rectangle,
                          borderRadius: BorderRadius.circular(5),
                          image: DecorationImage(
                            image: NetworkImage(cardsListArr[index].imgPoster),
                            fit: BoxFit.cover,
                          ),
                        ),
                        child: Container(
                          alignment: Alignment.bottomLeft,
                          child: Row(
                            children: [
                              IconButton(
                                  color: colorWhite,
                                  iconSize: 20,
                                  onPressed: () {},
                                  icon: Icon(Icons.play_arrow_rounded)),
                              Text(
                                "307k",
                                style: TextStyle(
                                    fontSize: 12, color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
            )
          ],
        ),
      ),
    );
  }
}
