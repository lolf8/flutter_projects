/// ApiStart : "18 days 21 hours 49 minutes 25 seconds 640 milliseconds 426 microseconds"
/// ApiEnd : "18 days 21 hours 49 minutes 25 seconds 640 milliseconds 433 microseconds"
/// status : true
/// message : "Data Found Successfully"
/// code : 200
/// result : {"Id":4,"Mp4Vd":"1633765143387.mp4","Mpd":"1633765143387_Output.mpd","Thumbnail":"1633765143387_Thumbnail.png","Description":"New video upload","ViewType":0,"Status":1,"CreatedBy":5,"CreatedOn":"2021-10-09T07:47:16.000Z","UpdatedBy":null,"UpdatedOn":null,"DeletedBy":null,"DeletedOn":null}

class Shortvideo {
  Shortvideo({
    String? apiStart,
    String? apiEnd,
    bool? status,
    String? message,
    int? code,
    Result? result,
  }) {
    _apiStart = apiStart;
    _apiEnd = apiEnd;
    _status = status;
    _message = message;
    _code = code;
    _result = result;
  }

  Shortvideo.fromJson(dynamic json) {
    _apiStart = json['ApiStart'];
    _apiEnd = json['ApiEnd'];
    _status = json['status'];
    _message = json['message'];
    _code = json['code'];
    _result = json['result'] != null ? Result.fromJson(json['result']) : null;
  }
  String? _apiStart;
  String? _apiEnd;
  bool? _status;
  String? _message;
  int? _code;
  Result? _result;

  String? get apiStart => _apiStart;
  String? get apiEnd => _apiEnd;
  bool? get status => _status;
  String? get message => _message;
  int? get code => _code;
  Result? get result => _result;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['ApiStart'] = _apiStart;
    map['ApiEnd'] = _apiEnd;
    map['status'] = _status;
    map['message'] = _message;
    map['code'] = _code;
    if (_result != null) {
      map['result'] = _result?.toJson();
    }
    return map;
  }
}

/// Id : 4
/// Mp4Vd : "1633765143387.mp4"
/// Mpd : "1633765143387_Output.mpd"
/// Thumbnail : "1633765143387_Thumbnail.png"
/// Description : "New video upload"
/// ViewType : 0
/// Status : 1
/// CreatedBy : 5
/// CreatedOn : "2021-10-09T07:47:16.000Z"
/// UpdatedBy : null
/// UpdatedOn : null
/// DeletedBy : null
/// DeletedOn : null

class Result {
  Result({
    int? id,
    String? mp4Vd,
    String? mpd,
    String? thumbnail,
    String? description,
    int? viewType,
    int? status,
    int? createdBy,
    String? createdOn,
    dynamic updatedBy,
    dynamic updatedOn,
    dynamic deletedBy,
    dynamic deletedOn,
  }) {
    _id = id;
    _mp4Vd = mp4Vd;
    _mpd = mpd;
    _thumbnail = thumbnail;
    _description = description;
    _viewType = viewType;
    _status = status;
    _createdBy = createdBy;
    _createdOn = createdOn;
    _updatedBy = updatedBy;
    _updatedOn = updatedOn;
    _deletedBy = deletedBy;
    _deletedOn = deletedOn;
  }

  Result.fromJson(dynamic json) {
    _id = json['Id'];
    _mp4Vd = json['Mp4Vd'];
    _mpd = json['Mpd'];
    _thumbnail = json['Thumbnail'];
    _description = json['Description'];
    _viewType = json['ViewType'];
    _status = json['Status'];
    _createdBy = json['CreatedBy'];
    _createdOn = json['CreatedOn'];
    _updatedBy = json['UpdatedBy'];
    _updatedOn = json['UpdatedOn'];
    _deletedBy = json['DeletedBy'];
    _deletedOn = json['DeletedOn'];
  }
  int? _id;
  String? _mp4Vd;
  String? _mpd;
  String? _thumbnail;
  String? _description;
  int? _viewType;
  int? _status;
  int? _createdBy;
  String? _createdOn;
  dynamic _updatedBy;
  dynamic _updatedOn;
  dynamic _deletedBy;
  dynamic _deletedOn;

  int? get id => _id;
  String? get mp4Vd => _mp4Vd;
  String? get mpd => _mpd;
  String? get thumbnail => _thumbnail;
  String? get description => _description;
  int? get viewType => _viewType;
  int? get status => _status;
  int? get createdBy => _createdBy;
  String? get createdOn => _createdOn;
  dynamic get updatedBy => _updatedBy;
  dynamic get updatedOn => _updatedOn;
  dynamic get deletedBy => _deletedBy;
  dynamic get deletedOn => _deletedOn;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['Id'] = _id;
    map['Mp4Vd'] = _mp4Vd;
    map['Mpd'] = _mpd;
    map['Thumbnail'] = _thumbnail;
    map['Description'] = _description;
    map['ViewType'] = _viewType;
    map['Status'] = _status;
    map['CreatedBy'] = _createdBy;
    map['CreatedOn'] = _createdOn;
    map['UpdatedBy'] = _updatedBy;
    map['UpdatedOn'] = _updatedOn;
    map['DeletedBy'] = _deletedBy;
    map['DeletedOn'] = _deletedOn;
    return map;
  }
}

/*===========Short Videos Database Model======*/

class ShortVideoDb {
  late final int? id;
  late final String? mp4Vd;
  late final String? mpd;
  late final String? thumbnail;
  late final String? description;
  late final int? viewType;
  late final int? status;
  late final String? createdBy;
  late final String? createdOn;

  ShortVideoDb({
    this.id,
    this.mp4Vd,
    this.mpd,
    this.thumbnail,
    this.description,
    this.viewType,
    this.status,
    this.createdBy,
    this.createdOn,
  });

  factory ShortVideoDb.fromMap(Map<String, dynamic> json) => ShortVideoDb(
        id: json['id'],
        mp4Vd: json['mp4vd'],
        mpd: json['mpd'],
        thumbnail: json['thumbnail'],
        description: json['description'],
        viewType: json['viewType'],
        status: json['status'],
        createdBy: json['createdBy'],
        createdOn: json['createdOn'],
      );
  Map<String, dynamic> toMap() => {
        "id": id,
        " mp4Vd": mp4Vd,
        "mpd": mpd,
        "thumbnail": thumbnail,
        "description": description,
        "viewType": viewType,
        "status": status,
        "createdBy": createdBy,
        "createdOn": createdOn,
      };
}
