import 'dart:async';

import 'package:path/path.dart';
import 'package:social/pages/pp/short_video.dart';
// import 'package:renao_ott/model/genres_model.dart';
// import 'package:renao_ott/model/language_model.dart';
// import 'package:renao_ott/model/short_video.dart';

import 'package:sqflite/sqflite.dart';
// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:path_provider/path_provider.dart';

class DB {
  Future<Database> initDB() async {
    String path = await getDatabasesPath();
    return openDatabase(
      join(path, "RENAODB.db"),
      onCreate: (database, version) async {
        // await database.execute("""
        //   CREATE TABLE ALLLANGUAGE(
        //     id INTEGER PRIMARY KEY  AUTOINCREMENT,
        //     langId INTEGER NOT NULL,
        //     lang_eng_name TEXT NOT NULL,
        //     lang_name TEXT NOT NULL,
        //     image TEXT ,
        //     usermapLangId INTEGER,
        //     status INTEGER
        //   )
        //   """);
        // await database.execute("CREATE TABLE SELECTEDLANGUAGE("
        //     "id INTEGER PRIMARY KEY  AUTOINCREMENT,"
        //     "langId INTEGER NOT NULL,"
        //     "lang_eng_name TEXT NOT NULL,"
        //     "lang_name TEXT NOT NULL,"
        //     "image TEXT,"
        //     "usermapLangId INTEGER,"
        //     "status INTEGER"
        //     ")");

        // await database.execute("CREATE TABLE GENRES ("
        //     "id INTEGER NOT NULL,"
        //     "name TEXT NOT NULL,"
        //     "images TEXT"
        //     ")");

        await database.execute("CREATE TABLE SHORTVIDEOS("
            "vid INTEGER PRIMARY KEY  AUTOINCREMENT,"
            "id INTEGER NOT NULL ,"
            "mp4Vd TEXT NOT NULL ,"
            "mpd TEXT NOT NULL,"
            "thumbnail TEXT NOT NULL,"
            "description TEXT,"
            "viewType INTEGER,"
            "status INTEGER,"
            "createdBy,"
            "createdOn"
            ")");
      },
      version: 1,
    );
  }

/*Insert Short Video data*/
  Future<bool> insertshortVideo(ShortVideoDb shortvideo) async {
    final Database db = await initDB();
    db.insert("SHORTVIDEOS", shortvideo.toMap());
    return true;
  }

  Future<List<ShortVideoDb>> getShortVideo() async {
    final Database db = await initDB();
    final List<Map<String, Object?>> datas =
        await db.query("SHORTVIDEOS", orderBy: "vid DESC");
    return datas.map((e) => ShortVideoDb.fromMap(e)).toList();
  }

// // Query for All Language Table
//   Future<bool> insertLanguage(LanguageDBModel languagedbModel) async {
//     final Database db = await initDB();
//     db.insert("ALLLANGUAGE", languagedbModel.toMap());
//     return true;
//   }

//   Future<List<LanguageDBModel>> getLanguage() async {
//     final Database db = await initDB();
//     final List<Map<String, Object?>> datas = await db.query("ALLLANGUAGE");
//     return datas.map((e) => LanguageDBModel.fromMap(e)).toList();
//   }

//   //Query for Selected Language
//   Future<bool> insertSelectedLanguage(
//       SelectedDbLanguage selectedDbLanguage) async {
//     final Database db = await initDB();
//     db.insert("SELECTEDLANGUAGE", selectedDbLanguage.toMap());
//     return true;
//   }

//   Future<List<SelectedDbLanguage>> getSelectedLanguage() async {
//     final Database db = await initDB();
//     final List<Map<String, Object?>> datas = await db.query("SELECTEDLANGUAGE");
//     return datas.map((e) => SelectedDbLanguage.fromMap(e)).toList();
//   }

//   // Query From Geners Table

//   Future<bool> insertGeners(GenersDatabaseModel genersdatabaseModel) async {
//     final Database db = await initDB();
//     db.insert(
//       "GENRES",
//       genersdatabaseModel.toMap(),
//       // conflictAlgorithm: ConflictAlgorithm.replace,
//     );
//     return true;
//   }

//   Future<List<GenersDatabaseModel>> getGeners() async {
//     final Database db = await initDB();
//     final List<Map<String, Object?>> datas = await db.query("GENRES");
//     return datas.map((e) => GenersDatabaseModel.fromMap(e)).toList();
//   }

//   Future<List<GenersDatabaseModel>> getGenresById(int id) async {
//     final db = await initDB();

//     // Query the table for all The GenersDatabaseModel.
//     final List<Map<String, dynamic>> datas =
//         await db.query("GENRES", where: "id = ", whereArgs: [id]);
//     // Convert the List<Map<String, dynamic> into a List<GenersDatabaseModel>.
//     return datas.map((e) => GenersDatabaseModel.fromMap(e)).toList();
//     // final db = await initDB();
//     // var result = await db.query("Product", where: "id = ", whereArgs: [id]);
//     // return result.isNotEmpty ? GenersDatabaseModel.fromMap(result.first) : Null;
//   }

//   genresupdate(GenersDatabaseModel genersDatabaseModel) async {
//     final db = await initDB();
//     var result = await db.update("GENRES", genersDatabaseModel.toMap(),
//         where: "id = ?", whereArgs: [genersDatabaseModel.id]);
//     return result;
//   }

//   Future<void> deleteGenres(int id) async {
//     // Get a reference to the database.
//     final db = await initDB();

//     // Remove the genres from the database.
//     await db.delete(
//       'GENRES',
//       // Use a `where` clause to delete a genres.
//       where: 'id = ?',
//       // Pass the Dog's id as a whereArg to prevent SQL injection.
//       whereArgs: [id],
//     );
//   }

//   Future<bool> emptyTable(String tablename) async {
//     final db = await initDB();
//     db.delete(tablename);
//     return true;
//   }

  // Future<void> dropTableIfExistsThenReCreateGnres() async {
  //   //here we get the Database object by calling the openDatabase method
  //   //which receives the path and onCreate function and all the good stuff
  //   final db = await initDB();
  //   await db.execute("GENRES");

  //   //and finally here we recreate our beloved "tableName" again which needs
  //   //some columns initialization
  //   await db.execute("CREATE TABLE GENRES ("
  //       "id INTEGER NOT NULL,"
  //       "name TEXT NOT NULL,"
  //       "images TEXT"
  //       ")");
  // }
}
