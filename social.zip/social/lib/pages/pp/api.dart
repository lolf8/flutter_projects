import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:social/pages/pp/database_query.dart';
import 'package:social/pages/pp/short_video.dart';
// import 'package:renao_ott/utils/database_query.dart';
// import 'package:socket_io_client/socket_io_client.dart' as io;

import 'package:socket_io_client/socket_io_client.dart';

late Socket socket;
late String connection = 'http://143.110.185.81:7070';
late String token =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9b1Bn0suVjilIi8W6QTEM.z6PXssjtTuzHhHSTR-S72sbBe2RdIJuD6LkZ97wIKn8b1Bn0suVjilIi8W6QTEM.b1Bn0suVjilIi8W6QTEMeyJJZCI6NSwidXNlcm5hbWUiOiJUYW55YTRSSVRaIiwiUm9sZUlkIjoyLCJTZWxlY3RTZXJ2aWNlIjowLCJTb2NrZXRJZCI6Imxhakx3R2l0TFVUc1NXVF9BQUFyIiwiU3RhdHVzIjoxLCJBY3RpdmUiOjEsImlhdCI6MTYzMzY3MjMxOCwiZXhwIjoxNjM0MjcyMzE4fQ';
void api() {
  try {
    // Configure socket transports must be sepecified
    socket = io(connection, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false,
    });

    socket.connect();
    socket.onConnect((data) => debugPrint("Connection Done"));
  } catch (e) {
    debugPrint(e.toString());
  }
}

void shortVideos() {
  try {
    socket.emit("/ShartvideoAll", {"token": token});
    socket.on("ShartvideoAll", (data) => setVideos(data));
  } catch (e) {
    debugPrint(e.toString());
  }
}

setVideos(data) {
  print(data);
  var shortvideo = Shortvideo.fromJson(data);
  print(shortvideo.result!.createdBy);
  insertShortVideos(shortvideo);
}
