import 'database_helper.dart';
import 'short_video.dart';

late DB db = DB();
// List<GenersDatabaseModel> datas = [];

insertShortVideos(Shortvideo shortVideo) async {
  await db.insertshortVideo(ShortVideoDb(
      id: shortVideo.result!.id!.toInt(),
      mp4Vd: shortVideo.result!.mp4Vd.toString(),
      mpd: shortVideo.result!.mpd.toString(),
      thumbnail: shortVideo.result!.thumbnail.toString(),
      viewType: shortVideo.result!.viewType!.toInt(),
      createdBy: shortVideo.result!.createdBy.toString(),
      createdOn: shortVideo.result!.createdOn.toString(),
      description: shortVideo.result!.description.toString()));
}
