import 'package:flutter/material.dart';
import 'package:social/pages/pp/api.dart';
import 'package:social/style/strings.dart';
import 'package:social/style/style.dart';

import 'one.dart';
import 'pages/audio_related.dart';
import 'utils/tik.dart';

void main() {
  api();
  shortVideos();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      supportedLocales: const [Locale('en', 'US')],
      title: appName,
      // theme: lightTheme,
      darkTheme: darkTheme,
      home: HomeWidget(),
    );
  }
}
