package com.example.social;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
